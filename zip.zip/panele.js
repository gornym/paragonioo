// panele (paragon, faktura, kart gwarancyjne)

const tabs = document.querySelectorAll(".przycisk_tab");
const tabsContainer = document.querySelector(".panel-naglowek");
const tabsContent = document.querySelectorAll(".panel_tresc");

tabsContainer.addEventListener("click", function (e) {
  const clicked = e.target.closest(".przycisk_tab");

  if (!clicked) return;

  tabs.forEach((t) => t.classList.remove("przycisk_tab-aktywny"));
  tabsContent.forEach((c) => c.classList.remove("panel_tresc-aktywny"));

  clicked.classList.add("przycisk_tab-aktywny");

  document
    .querySelector(`.panel_tresc-${clicked.dataset.tab}`)
    .classList.add("panel_tresc-aktywny");
});

// dodawanie zdjec
const firebaseConfig = {
  apiKey: "AIzaSyA7ZuB7n_Q8q1zvHYUEoo27yTB3uDxOFLM",
  authDomain: "paragonio-a9d51.firebaseapp.com",
  databaseURL:
    "https://paragonio-a9d51-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "paragonio-a9d51",
  storageBucket: "paragonio-a9d51.appspot.com",
  messagingSenderId: "376554158139",
  appId: "1:376554158139:web:be10cb845338b4eb72841e",
};

firebase.initializeApp(firebaseConfig);

var fileText = document.querySelector(".fileText");
var uploadPercentage = document.querySelector(".uploadPercentage");
var progress = document.querySelector(".progress");
var percentVal;
var fileItem;
var fileName;
var img = document.querySelector(".img");

function getFile(e) {
  fileItem = e.target.files[0];
  fileName = fileItem.name;
  fileText.innerHTML = fileName;
}

function uploadImage() {
  let user = firebase.auth().currentUser;
  if (user) {
    let userId = user.uid;
    let storageRef = firebase.storage().ref(userId + "/images/" + fileName);
    let uploadTask = storageRef.put(fileItem);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        console.log(snapshot);
        percentVal = Math.floor(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        console.log(percentVal);
        uploadPercentage.innerHTML = percentVal + "%";
        progress.style.width = percentVal + "%";
      },
      (error) => {
        console.log("error is", error);
      },
      () => {
        uploadTask.snapshot.ref.getDownloadURL().then((url) => {
          console.log("URL", url);

          if (url != "") {
            img.setAttribute("src", url);
            img.style.display = "block";
          }
        });
      }
    );
  }
}
